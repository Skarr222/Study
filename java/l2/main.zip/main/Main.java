package l2.main;

public class Main {
    public static void main(String[] args) {
        Osoba osoba1 = new Osoba("Jan", "Kowalski", "1990-01-01",
                "ul. Kowalska 1, 00-000 Warszawa");
        Uzytkownik uzytkownik1 = new Uzytkownik("1", "2020-01-01",
                "Jestem typowym użytkownikiem na poziomie średniozaawansowanym",
                 osoba1);

        Produkt produkt1 = new Produkt("1", "Pierwszy produkt",
                "Typ 1", "Opis produktu jeden", 1241.0);
        Produkt produkt2 = new Produkt("2", "Drugi produkt",
                "Typ 2", "Opis produktu dwa", 2231.0);

        Opinia opinia1 = new Opinia("1", "Treść jeden",
                "2020-01-01", uzytkownik1, produkt1);
        Opinia opinia2 = new Opinia("2", "Treść dwa",
                "2020-01-02", uzytkownik1, produkt2);

        uzytkownik1.zwiekszHistorieWystawionychOpinii(0, opinia1);
        uzytkownik1.zwiekszHistorieWystawionychOpinii(1, opinia2);
        uzytkownik1.wyswietlWszystkieOpinie();
    }
}
